 /*Sudi Yussuf*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "headers2.h"


/*instructionsto print parents of a node*/
void printParentsInstruction(Node* head){
	Node *tmp = head;
	Node *tmp1,*tmp2;
	char first[100];
	char last[100];
	char *first1, *last1;
	
	printf("Provide the first name of the node whose parents you would like to print\n");
	scanf("%s", &first);
	
	printf("Provide the last name of the node whose parents you would like to print\n");
	scanf("%s", &last);
	
	first1 = first;
	last1 = last;
	/*find node using first and last name*/
	tmp2 = findNodeName1(tmp,first1,last1);
	
	printParents(tmp2);
	menu(tmp);

}

/*instructionsto print parents of a node*/
void printChildrenInstruction(Node* head){
	Node *tmp = head;
	Node *tmp1,*tmp2;
	char first[100];
	char last[100];
	char *first1, *last1;
	
	printf("Provide the first name of the node whose children you would like to print\n");
	scanf("%s", &first);
	
	printf("Provide the last name of the node whose children you would like to print\n");
	scanf("%s", &last);
	
	first1 = first;
	last1 = last;
	/*find node using first and last name*/
	tmp2 = findNodeName1(tmp,first1,last1);
	
	printChildren(tmp2);
	menu(tmp);

}


/*instructions to delete a node*/
void deleteIndividualInstruction(Node *head){
	int id, i;
	Node *tmp = head;
	Node *tmp1,*tmp2;
	char first[100];
	char last[100];
	char *first1, *last1;

	
	

	printf("Provide first name of the node you would like to delete\n");
	scanf("%s", &first);
	
	printf("Provide last name of the node you would like to delete\n");
	scanf("%s", &last);
	
	first1 = first;
	last1 = last;
	
	/*delete node using first and last name*/
	deleteParent(tmp, first1, last1);
	printf("Returning to Menu!");
	menu(tmp);
	

}

/*instructions to add a child to a collection*/
void addChildToCollection(Node *head){
	int id, i;
	Node *tmp = head;
	Node *tmp1,*tmp2;
	char first[100];
	char last[100];

	
	
	printf("Provide an integer as an id of the colleciton you would like to add a child to\n");
	scanf("%d", &id);

	printf("Provide first name of the child you would like to add\n");
	scanf("%s", &first);
	
	printf("Provide last name of the child you would like to add\n");
	scanf("%s", &last);
	
	
	/*find node using first and last name, and collection id*/
	tmp1 = findNodeName1(tmp, first, last);
	tmp2 = findCollection(tmp, id);
	addToChildrenArray(tmp2, tmp1);
	printf("Returning to Menu!");
	menu(tmp);

}

/*instructions to add a parent to a collection*/
void addParentToCollection(Node *head){
	int id, i;
	Node *tmp = head;
	Node *tmp1,*tmp2;
	char first[100];
	char last[100];

	
	
	printf("Provide the integer id of the colleciton you would like to add a parent to\n");
	scanf("%d", &id);

	printf("Provide the string first name of the parent you would like to add\n");
	scanf("%s", &first);
	
	printf("Provide the string last name of the parent you would like to add\n");
	scanf("%s", &last);

	/*find node using first and last name, and collection id*/
	tmp1 = findNodeName1(tmp, first, last);
	tmp2 = findCollection(tmp, id);
	addToParentsArray(tmp2, tmp1);
	printf("Returning to Menu!");
	menu(tmp);

}

/*instructions to create an indicidual node*/
void createIndividualInstruction(Node *head){
	int id, i;
	Node *tmp = head;
	Node *tmp1;
	char first[100];
	char last[100];

	printf("Create a Child!\n");
	printf("Provide an integer as an id!\n");
	scanf("%d", &id);

	printf("Provide first name\n");
	scanf("%s", &first);
	
	printf("Provide last name\n");
	scanf("%s", &last);

	/*create node using first and last name, and automatically add it to the head node*/
	tmp1 = createIndividualNode(id, first, last);
	addToChildrenArray(tmp, tmp1);
	printf("Returning to Menu!");
	menu(tmp);
}

/*instructions to create collection*/
void createCollectionInstruction(Node *head){
	int id, i;
	Node *tmp = head;
	Node *tmp1, *tmp12,*tmp6;
	char first[100];
	char last[100];
	printf("Create a collection!\n");
	printf("Provide an integer as an id!\n");
	scanf("%d", &id);

	/*create the collection using an id*/
	tmp6 = createCollectionNode(tmp,id);
	printf("Collection %d has been created \n", id);

	printf("Returning to Menu!");
	menu(tmp);

}

/*instructions to find a node*/
void findNodeInstructions(Node *head){

	Node *tmp = head;
	Node *tmp1,*tmp2;
	char first[100];
	char last[100];
	char *first1, *last1;

	
	

	printf("Provide first name of the indidual you would like to find\n");
	scanf("%s", &first);
	
	printf("Provide last name of the individual you would like to find\n");
	scanf("%s", &last);
	
	first1 = first;
	last1 = last;

	/*call findnode using a first and last name*/
	tmp2 = findNodeName1(tmp,first1,last1);
	
	/*print success if the id of an individual exists*/
	if(tmp2 != NULL){
		printf("The id of the node you are looking for is %d\n", tmp2->id);	
		printf("The this individual belongs to the collection number %d\n", tmp2->prior->id);
	}
	menu(tmp);



}



/*menu function*/
void menu(Node* head){
	Node *tmp = head;
	int choice;
	int count = 0;
	char choices[9] = {'a','b','c','d','e','f','g','h'};
	/*printed instructions*/
	printf("\nHello! Welcome to the menu!\n");
	printf("Press '1' if you would like to create a new Collection!\n");
	printf("Press '2' if you would like to create a new Individual!\n");
	printf("Press '3' if you would like to add a child too a collection!\n");
	printf("Press '4' if you would like to add a parent too a collection!\n");
	printf("Press '5' if you would like to delete an individual!\n");
	printf("Press '6' if you would like to print the children of a parent node!\n");
	printf("Press '7' if you would like to print the parents of a child node!\n");
	printf("Press '8' if you would like to know the number of nodes in the tree!\n");
	printf("Press '9' if you would like to search the tree for a specific person!\n");
	printf("Press '10' if you would like to quit!\n");
	

	scanf("%d", &choice);
	
	/*call to different commands using the integers*/
	if(choice == 1){
		createCollectionInstruction(tmp);
	}
	else if(choice == 2){
		createIndividualInstruction(tmp);
	}
	else if(choice == 3){
		addChildToCollection(tmp);
	}
	else if(choice == 4){
		addParentToCollection(tmp);
	}
	else if(choice == 5){
		deleteIndividualInstruction(tmp);
	}
	else if(choice == 6){
		printChildrenInstruction(tmp);
	}
	else if (choice == 7){
		printParentsInstruction(tmp);
	}
	else if (choice ==8){
		count = countNodes(tmp);
		printf("There are %d nodes in the tree", count);
		menu(tmp);
	}
	else if (choice == 9){
		findNodeInstructions(tmp);
	}
	else if (choice == 10){
		printf("Goodbye!");
		exit(0);
	}
	else {	
		printf("invalid command, try again.");
		menu(tmp);
	}


}




