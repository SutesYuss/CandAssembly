/*Sudi Yussuf*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include "headers2.h"


void printlist(Node *head) {
	
	/*create a temp node pointer that is head*/
	Node *temp = head;
	
	/*runs while node pointer is not null
	moving to the next pointer each time*/
	while (temp !=NULL) {
		printf("%d - ", temp->id);
		temp = temp->next;
	}
	printf("\n");
	

}

void printChildren(Node *parent){
	
	Node *temp = parent->next;
	Node *j;
	int i,x;
	
	/*runs while node pointer is not null
	moving to the next pointer each time*/
	if (temp !=NULL) {
		x = temp->childrenSize;
		if(x==0){
			/*if there are no chidren*/
			printf("This Node has no children.");
		}
		else{
			printf("This nodes children are: ");
			for(i = 0; i < x; i++){
				j = temp->children[i];
				if(j!= NULL){
					printf("%d - ", j->id);
				}
			}
		}
	}
	else{
		printf("This Node has no children.");
	}
	printf("\n");
	
}
void printParents(Node *child){
	
	Node *temp = child->prior;
	Node *j;
	int i,x;
	
	/*runs if node pointer is not null
	moving to the next pointer each time*/
	if (temp !=NULL) {
		x = temp->parentSize;
		if(x>0){
			/*if there are no parents*/
			printf("This nodes parents are: ");
			
			for(i = 0; i < x; i++){
				j = temp->parents[i];
				if(j!= NULL){
					printf("%d - ", j->id);
				}
			}
		}
		else{
			printf("This node has no parents.");
			
		}
	}
	printf("\n");
	
}

void printCollections(Node *collection){
	
	Node *temp = collection;
	Node *j;
	int i,x;
	
	/*runs if node pointer is not null
	moving to the next pointer each time*/
	if (temp !=NULL) {
		x = temp->collectionSize;
		for(i = 0; i < x; i++){
			j = temp->collections[i];
			if(j!= NULL){
				printf("%d - ", j->id);
			}
		}
	}
	printf("\n");
	
}

/*this function finds a node from the tree*/
Node *findNodeName1(Node *head, char* first, char* last){
	
	Node *tmp = head;
	Node *j, *k;
	int x = 0;
	int i = 0;
	int count = countNodes(tmp);
	int countLoops = 0;
	
		/*if the head node is a collection*/
		if(tmp->type==1){
			x = tmp->collectionSize;
			/*for each collection*/
			for(i = 0; i < x; i++){
				j = tmp->collections[i];
				if(tmp != NULL){
					x = tmp->childrenSize;
					/*for each child within collection*/
					for(i = 0; i < x; i++){
						j = tmp->children[i];
						countLoops++;
						/*check if the current child has the name were looking for*/
						if(!(strcmp(j->first,first) && 
						strcmp(j->last,last))){
							return j;
						}
						if(countLoops==count){
							goto exit;
						}
					}
				}
				
			}
			
		}
	
	
	exit:
	
	printf("This individual does not exist in the tree.");
	return NULL;
	/*read each collection*/

	/*read each child in collection*/
}

Node *findCollection(Node *head, int id){

Node *tmp = head;
	Node *j, *k;
	int x,i;
	
	/*check for collection in collections array*/
	while(tmp != NULL){
		if(tmp->type==1){
			x = tmp->collectionSize;
			/*for each collection*/
			for(i = 0; i < x; i++){
				j = tmp->collections[i];
				/*if the current collection is the same as the one were looking for*/
				if(j->id ==id){
					return j;
				}
			}
			
		}
	}
	
	
	printf("This Collection does not exist!");
	return NULL;


}


int countNodes(Node *head){

	int count = 0;
	Node *tmp = head;
	Node *j, *k;
	int x,i;
	int childrenSize = 0;
	
	/*count top level nodes*/
	for(i = 0; i < tmp->childrenSize; i++){
		if(tmp->children[i]->prior == tmp){
			childrenSize++;
		}


	}
	/*if head is not null*/
	if(tmp!= NULL){
		if(tmp->type==1){
			x = tmp->collectionSize;
			/*ffor each child in the collections*/
			for(i = 0; i < x; i++){
				j = tmp->collections[i];
				childrenSize = childrenSize +j->childrenSize;
			}
		}
	}
		/*total counts*/
		count = childrenSize;
	
	return count;


}

