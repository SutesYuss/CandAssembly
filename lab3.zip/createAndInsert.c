/*Sudi Yussuf*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "headers2.h"


/*function creates an individual node*/
Node *createIndividualNode(int id, char* first, char* last) {
	/*create a node*/
	Node *result = malloc(sizeof(Node));
	Node* tmp1;

	/*define variables if the node is successfully created*/
	if (result == NULL) {
		printf("ERROR: Could not allocate space for node");
		abort();
	}
	else {
		
		result->type = 0;
		strcpy(result->first, first);
		strcpy(result->last, last);
		result->id = id;
		result->next = NULL;
		result->prior = NULL;
	}
	/*return the node that was created*/
	return result;
}

/*create a collection node*/
Node *createCollectionNode(Node *head,int id) {
	/*create empty node and temp node*/
	Node* tmp = head;
	Node* thisCollection;
	Node *result = malloc(sizeof(Node));
	int collectionArraySize = 0;
	int same = 0;
	int i = 0;

	/*if the node is the head node*/
	if(id == 0){
		result->type = 1;
		result->childrenSize = 0;
		result->parentSize = 0;
		result->collectionSize = 0;
		result->id = id;
		result->next = NULL;
		result->prior = NULL;


	}
	/*define variables if node is successfully created, otherwide print error.*/
	else{
		if (result == NULL) {
			printf("ERROR: Could not allocate space");
			abort();
		}
		else {
			result->type = 1;
			result->childrenSize = 0;
			result->parentSize = 0;
			result->collectionSize = 0;
			result->id = id;
			result->next = NULL;
			result->prior = NULL;

			collectionArraySize = tmp->collectionSize;
			for(i = 0; i <collectionArraySize; i++){
				thisCollection = tmp->collections[i];
				if(thisCollection->id == result->id){
					same = 1;
				}
			}
			if(same == 0){
				tmp->collections[collectionArraySize] = result;
				tmp->collectionSize = collectionArraySize+1;
			}
		}
	}
	
	return result;
}


/* Inserts a node at the head. You can change the head pointer because we are passing in a pointer to a pointer*/
Node *insertAtHead(Node **head, Node *nodeToInsert){
	
	nodeToInsert->next = *head;
	*head = nodeToInsert;
	return nodeToInsert;

}

/* Inserts a node after a specific node.*/
void insertAfterNode(Node *nodeToInsertAfter, Node *newNode) {
	
	newNode->next = nodeToInsertAfter->next;
	nodeToInsertAfter->next = newNode;

}



