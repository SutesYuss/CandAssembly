 /*Sudi Yussuf*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "headers2.h"


/*function to read names from a file*/
int readFile(FILE *file, Node *head){
	
	Node *tmp = head;
	Node *tmp1;
	char line[1000];
	char *p = NULL;
	int i;
	int j =1;
	char *first;
	char *last;

	/*if the file is not null*/
	if (file != NULL) {
		/*while lines exist in file*/
		while(fgets(line,sizeof(line),file)!= NULL) {		
			i = 0;
			/*break string into spaces*/
			p = strtok(line," ");
			while(p != NULL){
				i++;
				/*split line into first and last name*/
				if(i==1){
					first = p;
				}
				else{
					last = p;
				}
				p = strtok(NULL," ");
				
			   }			
			/*if a first AND last name exist*/
			if(i ==2 && j<=16){
				/*create node, and add it to head top level*/
				tmp1 =createIndividualNode(j,first,last);
				printf("\nCreated node %d \n", tmp1->id);
				addToChildrenArray(tmp,tmp1);
				j++;
			}
			else{
				printf("Invalid number of commands for this node");
				
			}
			
		}
		/*close file*/

		fclose(file);
	}
	else {
		printf("Error: could not open file!");
	}

	return 0;
}



int main(int argc, char *argv[]){
	/*createCollection();*/
	Node *tmp;
	FILE *fileHandle;
	fileHandle = fopen(argv[1], "r");
	tmp = createCollectionNode(tmp,0);


	/*if a commandline arg is presented*/
	if(argc >1){
		readFile(fileHandle,tmp);
	}
		menu(tmp);



	return 0;


}




