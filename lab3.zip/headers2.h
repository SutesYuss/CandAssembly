 /*Sudi Yussuf*/
/*This header file contains macros*/
#include <stdlib.h>
#include <stdio.h>
#include <string.h>




struct node {
	/*Flag for node type*/
	int type;

	/*id for future differentiating*/
	int id;

	/* Names for individuals only*/
	char first[50];
	char last[50];

	/*Sizes of the parent and children arrays for collections only*/
	int childrenSize;
	int parentSize;
	int collectionSize;

	/*next node in web for individuals only*/
	/*next node for collections will be reached via children array*/
	struct node *next; 
	struct node *prior; 
	/*Arrays of pointers for collections only */
	struct node *parents[16];
	struct node *children[32];
	struct node *collections[100];

	
	
};
/*turn Node into a typedef*/
typedef struct node Node;

/*function prints list of all nodes*/
void printlist(Node*);

/*function prints all children of a node*/
void printChildren(Node*);

/*function prints all parents of a node*/
void printParents(Node*);

/*function prints all collections of a tree*/
void printCollections(Node*);

/*function finds individual node in tree*/
Node *findNodeName1(Node*, char*, char*);

/*function finds collection node in tree*/
Node *findCollection(Node*, int);

/*function creates an individual node*/
Node *createIndividualNode(int, char*, char*);

/*function creates a collection node*/
Node *createCollectionNode(Node*, int);

/* Inserts a node at the head. You can change the head pointer because we are passing in a pointer to a pointer*/
Node *insertAtHead(Node**, Node*);

/*inserts node after some other node*/
void insertAfterNode(Node*, Node*);

/*adds to parent array of a collection*/
void addToParentsArray(Node*, Node*);

/*adds to children array of a collection*/
void addToChildrenArray(Node*, Node*);

/*deletes a node form a tree*/
void deleteParent(Node*, char*, char*);

/*shows menu with instructions*/
void menu(Node*);

/*instruction functions*/
void printChildrenInstruction(Node*);

void printParentsInstruction(Node*);

void deleteIndividualInstruction(Node*);

void addChildToCollection(Node*);

void addParentToCollection(Node*);

void createIndividualInstruction(Node*);

void createCollectionInstruction(Node*);

void findNodeInstructions(Node*);

/*counts nodes in tree*/
int countNodes(Node*);

/*reads file from argv*/
int readFile(FILE*,Node*);



