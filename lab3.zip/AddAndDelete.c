/*Sudi Yussuf*/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "headers2.h"



/*function adds a node to the parent array of a collection*/
void addToParentsArray(Node *collectionNode, Node *parentNode){
	
	int parentArraySize = collectionNode->parentSize;
	int collectionArraySize, i;
	int same = 0;
	Node *j, *thisCollection;
	
	/*add parent to parent array*/
	parentNode->next = collectionNode;
	collectionNode->parents[parentArraySize] = parentNode;
	collectionNode->parentSize = parentArraySize+1;
	
	/*if parent is the child of another function add this collection to the 
	that prior nodes collection array*/
	if(parentNode->prior != NULL){
		j = parentNode->prior;
		collectionArraySize = j->collectionSize;
		collectionNode->prior = j;
		for(i = 0; i <collectionArraySize; i++){
			thisCollection = j->collections[i];
			if(thisCollection->id == collectionNode->id){
				same = 1;
			}
		}
		/*if the collection alreaddy exists in the collection array*/
		if(same == 0){
			j->collections[collectionArraySize] = collectionNode;
			j->collectionSize = collectionArraySize+1;
		}
		
	}



	

}

/*add a node to the children array of a collection node*/
void addToChildrenArray(Node *collectionNode, Node *childNode){
	
		
	int arraySize = collectionNode->childrenSize;
	int pastArraySize;
	int i,k,index;
	Node *tmp4;
	
	/*add child to child array*/
	childNode->prior = collectionNode;
	collectionNode->children[arraySize] = childNode;
	collectionNode->childrenSize = arraySize+1;
	collectionNode->next = childNode->next;

	
}

void deleteParent(Node *head, char* first, char* last){
	
	Node *tmp = head;
	Node *tmp1, *tmp3, *tmp4, *tmp5;
	int i, j, k, parentsArraySize, childrenArraySize, index;
	tmp1 = findNodeName1(tmp, first, last);

	/*if the head node is not empty*/
	if(tmp != NULL){
		printParents(tmp1);
		/*if the current node to delete is not null*/
		if(tmp1 != NULL){
			tmp3 = tmp1->next;
			if(tmp3 != NULL){
				parentsArraySize = tmp3->parentSize;
				/*delete the element from the parents array and fix the array size*/
				for(i = 0; i <parentsArraySize; i++){
					tmp4 = tmp3->parents[i];
					if(tmp1->id == tmp4->id){
						index = i;
						j = 0;
						if(index <(parentsArraySize-1)){
						for(k = index; k<(parentsArraySize-1);k++){
						
						tmp3->parents[k]= 		
						tmp3->parents[k+1];
						
						}}
						
						tmp3->parentSize = parentsArraySize-1;
						printf("\n");
					}
				}
			}
		}
		/*do the same thing as above for the children array and fix the array size*/
			tmp5 = tmp1->prior;
			if(tmp5 != NULL){
				childrenArraySize = tmp5->childrenSize;
				for(i = 0; i <childrenArraySize; i++){
					tmp4 = tmp5->children[i];
					if(tmp1->id == tmp4->id){
						index = i;
						j = 0;
						
						if(index <(childrenArraySize-1)){
						for(k = index; k<(childrenArraySize-1);k++){
								if(k ==childrenArraySize-1){
							tmp5->children[index] = NULL;
								
								}else{
							tmp5->children[k]= tmp5->children[k+1];
							}
						
							
						}
						}
						tmp5->childrenSize = childrenArraySize-1;
						/*free the deleted node*/
						printf("\n");
						free(tmp1);
						tmp1 = NULL;
						break;
					}
				}
			}
			
		}

}
