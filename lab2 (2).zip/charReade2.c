/*Sudi Yussuf*/

#include "functions.h"
#include "headers2.h"
#include <stdio.h>
#include <math.h>


/*reads chars from a file 7 at a time and 
decrypts them */
char sevenAtATime(char ch){

	/*array that contains 7 chars at a time*/
	char charArr[7];
	/*create all the variables necessary*/
	int extractedBit, newChar, charIndex, lastChar, arrIndex, bitIndex;
	int i = 0;
	int eigthVal = 0;

	/*loop fills the array with 7 chars*/
	while(ch != EOF && ch != '\n' && i <=6){
		charArr[i] = ch;
		ch= (char)getchar();
		i = i + 1;
	}

	/*statement runs if there are less than 7 chars in the array*/
	if(i <=6){
		/*signals that the file has ended*/
		ch = EOF;
		arrIndex = 0;
		/*loop prints the chars (<7) into the output file with no changes*/
		while(i!=0){
			putchar((char)charArr[arrIndex]);
			arrIndex =  arrIndex+1;
			i = i-1;
		}
	}

	/*statement runs if there are 7 chars in the array*/
	else{
		bitIndex  = 0;
		charIndex = EIGHT;
		/*loop runs once for every char in the array*/
		while(bitIndex<7) {
			/*grab the current char*/
			lastChar = (int)charArr[bitIndex ];

			/*extracts the necessary bit from the last char
			using the extract function*/
			extractedBit = extract(lastChar, charIndex);

			/*restore to the original char*/
			newChar = insert_bit2((int)charArr[bitIndex], extractedBit, charIndex);
		
			/*print the new character*/
			putchar((char)newChar);
	
			/*calculate and restore the last char with extracted bit values*/
			eigthVal = eigthVal + (extractedBit * pow(2,bitIndex));
			bitIndex  = bitIndex  + 1;
			charIndex = charIndex - 1;
		} 
		/*print the restored eigth char*/
		putchar((char)eigthVal);
	}
	return ch;
}


/*main method*/
int main(){

	/*grab the first char in the input file*/
	char ch = (char)getchar();
	char gh = 'i';
	int i = 0;

	/*This while loop runs until all the chars
	in a file have been read*/
	while(ch != EOF && ch != '\n'){
		/*call to function that reads file 7 chars at a time*/
		ch =sevenAtATime(ch);
	}


	return 0;


}

