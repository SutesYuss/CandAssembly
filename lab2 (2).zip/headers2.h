 /*Sudi Yussuf*/
/*This header file contains macros*/
#define EIGHT 8
