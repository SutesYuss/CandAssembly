 /*Sudi Yussuf*/

#include "functions.h"
#include "headers2.h"
#include <stdio.h>
#include <math.h>

/*reads chars from a file 8 at a time and 
encrypts them */
char eigthAtATime(char ch){

	/*array that contains 8 chars at a time*/
	char charArr[8];
	/*create all the variables necessary*/
	int extractedBit, newChar, charIndex, eigthChar, arrIndex, bitIndex;
	int i = 0;

	/*loop fills the array with 8 chars*/
	while(ch != EOF && ch != '\n' && i <=7){
		charArr[i] = ch;
		ch= (char)getchar();
		i = i + 1;
	}
	
	/*statement runs if there are less than 8 chars in the array*/
	if(i <=7){
		/*signals that the file has ended*/
		ch = EOF;
		arrIndex = 0;
		/*loop prints the chars (<8) into the output file with no changes*/
		while(i!=0){
			putchar((char)charArr[arrIndex]);
			arrIndex =  arrIndex+1;
			i = i-1;
		}
	}
	
	/*statement runs if there are 8 chars in the array*/
	else{
		bitIndex = 0;
		charIndex = EIGHT;
		/*loop runs once for every char in the array*/
		while(bitIndex<7) {
			/*grab the last char (8th)*/
			eigthChar = (int)charArr[7];

			/*extracts the necessary bit from the last char
			using the extract function*/
			extractedBit = extract(eigthChar, bitIndex+1);
			
			/*insert the bit into the character at the given position
			using the exract function*/
			newChar = insert_bit((int)charArr[bitIndex], extractedBit, charIndex);
			
			/*print the new character*/
			putchar((char)newChar);

			bitIndex = bitIndex + 1;
			charIndex = charIndex - 1;
		} 
	}

	return ch;
}


/*main method*/
int main(){

	/*grab the first char in the input file*/
	char ch = (char)getchar();
	int i = 0;

	/*This while loop runs until all the chars
	in a file have been read*/
	while(ch != EOF && ch != '\n'){
		/*call to function that reads file 8 chars at a time*/
		ch = eigthAtATime(ch);
	}

	
	return 0;


}



