 /*Sudi Yussuf*/

#include "functions.h"
#include "headers2.h"
#include <stdio.h>
#include <math.h>


char eigthAtATime(char ch){

	char charArr[8];
	int x, y, z, a, b, c;
	int i = 0;
	while(ch != EOF && ch != '\n' && i <=7){
		charArr[i] = ch;
		ch= (char)getchar();
		i = i + 1;
		
		if(i>7)
			break;
	}
	
	if (i>=8 && i)
		goto e;		
		
	if(i <=7){
		ch = EOF;
		b = 0;
		while(i!=0){
			putchar((char)charArr[b]);
			b =  b+1;
			i = i-1;
			continue;
		}
	}
	else{
		e:
		c = 0;
		z = EIGHT;

		while(c<7) {
			a = (int)charArr[7];
			x = extract(a, c+1);
			y = insert_bit((int)charArr[c], x, z);
			
			putchar((char)y);
			c = c + 1;
			z = z - 1;
		} 
	}

	return ch;
}


int main(){
	char ch = (char)getchar();
	char gh;
	int i = 0;
	while(ch != EOF && ch != '\n'){
		ch =eigthAtATime(ch);
		

	}

	
	return 0;


}



