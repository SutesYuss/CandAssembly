/*Sudi Yussuf*/
/*This header file contains function 
prototypes for all functions except 
main and library functions */
#include "headers2.h"
#include <stdio.h>
#include <math.h>


/*function is written in charReader.c*/
/*reads chars from a file 8 at a time and 
encrypts them */
char eigthAtATime(char ch);

/*function is written in charReade2.c*/
/*reads chars from a file 7 at a time and 
decrypts them */
char sevenAtATime(char ch);


/*extract one bit from a number in a given position*/
int extract(int number, int position){
	
	/*create a bit mask and extract a single bit*/
	return (((1 << 1) - 1) & (number >> (position - 1)));

}



int insert_bit(int number, int extractedNum, int position){
	int compare, inters, comp3, mask, mask2, isolated,isolated2;
	/*isolate bits*/
	mask = ((1 << (EIGHT -(position-1))) -1) << (position-1);
	mask2 = ((1 << (position)) -1);
	isolated = ((number & mask) <<1);
	isolated2 = (number & mask2);
	inters = isolated | isolated2;
	
	if (extractedNum == 0){
		compare = (inters & (~(1 << (position - 1))));
	}
	else{
		compare = (inters | (1 << (position - 1)));
	}

	
	return compare;

}

/*function is called in charReade2.c*/
/*takes an extracted bit, position, and an int casted char and 
removes the bit at the given positon from the int*/
int insert_bit2(int number, int extractedNum, int position){

	/*declare necessary variables*/
	int compare, inters, comp3, mask, mask2, isolated,isolated2;
	/*isolate bits to left shift and bits to keep intact*/
	mask = ((1 << (EIGHT - (position ))) -1) << (position);
	mask2 = ((1 << (position -1)) -1);

	/*use the bit masks to isolate the ranges of bits */
	isolated = ((number & mask) >>1);
	isolated2 = (number & mask2);

	/*get the original number by using bitwise OR on the 2
	isolated values*/
	inters = isolated | isolated2;
	
	
	return inters;

}
