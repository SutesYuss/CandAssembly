/*Sudi Yussuf*/
#include <stdio.h>
#include <stdlib.h>

#include "lab4.h"

void pushs1(void *this1, int x){
	/*Cast the void pointer and allocate space for LLNode.*/
	Stack1 *this= (Stack1*)this1;
	LLNode *new = malloc(sizeof(LLNode));

	/*Check if stack exists and LLnode was successfully allocated*/
	if(this == NULL){
		printf("Could not push element. Stack does not exist: exiting session.");
		exit(0);
	}

	if(new == NULL){
		printf("Could not allocate space for LLNode");
		exit(0);
	}else{
		/*Set members of LLNode and Stack1 and push the element.*/
		new->data = x;
		new->next = this->firstNode;
		this->firstNode = new;
		this->length = this->length + 1;
	}
	
	
}

int pops1(void  *this1){
	/*Cast the void pointer and extract data.*/
	Stack1 *this= (Stack1*)this1;
	int x;
	LLNode *tmp, *tmp2;

	if(this == NULL){
		printf("Could not push element. Stack does not exist: exiting session.");
		exit(0);
	}
	
	tmp = this->firstNode;
	if(tmp == NULL){
		printf("Stack is empty: returning 0.\n");
		return(0);
	}else{
		x = this->firstNode->data;

		/*pop element and change the head node*/
		
		tmp2 = this->firstNode->next;
		free(tmp);
		tmp = NULL;
		this->firstNode = tmp2;
		this->length = this->length - 1;
	}
	
	return x;
}

/*This function sets the length*/
int lengths1(void  *this1){
	Stack1 *this= (Stack1*)this1;
	if(this == NULL){
		printf("Could not get length. Stack does not exist: exiting session.");
		exit(0);
	}
	return this->length;
}

/*Set a new Structure of type Stack1 and set it with default values*/
Stack1* newStack1Make(){
	Stack1 *newStack = malloc(sizeof(Stack1));
	/*Check if stack allocation faialed*/
	if(newStack == NULL){
		printf("Could not allocate space for Stack1");
		exit(0);
	}else{
		newStack->length = 0;
		newStack->firstNode = NULL;
	}
	return newStack;
}


/*Set a new Structure of type Stack and set it with default values*/
/*The Stack member will be set to type Stack1*/
Stack* newStack1(){
	Stack *newStack = malloc(sizeof(Stack));
	/*Check if allocation failed.*/
	if(newStack == NULL){
		printf("Could not allocate space for Stack\n");
		exit(0);
	}else{
		newStack->Stack = newStack1Make();
		newStack->push = &pushs1;
		newStack->pop= &pops1;
		newStack->length= &lengths1;
	}
	
	return newStack;

}
