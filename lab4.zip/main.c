/* Sudi Yussuf */

/* Reminder if you play league to feed the poros in ARAM. */

#include <stdio.h>
#include <stdlib.h>

#include "lab4.h"
#include <time.h>



void StackTest(int type){
	/*Declare the clock and time variables.*/
	clock_t start, end;
	double cpu_time_used;
	
	/*Set stack type based on the type parameter.*/
	Stack* newStack = type == 1 ? newStack1() : newStack2();
	int i, removed, errors;
	errors = 0;
	
	/*Set the start time for the clock.*/
	start = clock();

	/*Run these loops to fill the stack with elements, and then take all the elements out*/
	for(i = 0; i <BIG_NUM; i++){
		newStack->push(newStack->Stack, i);
	}

	for(i = 0; i < BIG_NUM; i++){
		removed = newStack->pop(newStack->Stack);
		if(removed != BIG_NUM - i - 1 && (BIG_NUM - i - 1) > DEFAULT_RESULT){
			printf("Expected %i, removed %i\n", BIG_NUM - i - 1, removed);
			errors++;
		}else{
			/*printf("Expected %i, removed %i\n", BIG_NUM - i - 1, removed);*/
		}
	}
	
	/*print errors and clock time*/
	printf("Ended with %i errors\n", errors);	
	end = clock();
	cpu_time_used = ((double) (end - start)) / CLOCKS_PER_SEC;
	printf("Stack%d: clock time is %f\n",type, cpu_time_used);

}

int main(int argc, char *argv[]){

	/*Test the 2 stack types by calling StackTest()*/
	StackTest(1);
	StackTest(2);
	
	

	return 0;
}
