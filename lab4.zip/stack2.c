/*Sudi Yussuf*/
#include <stdio.h>
#include <stdlib.h>

#include "lab4.h"


/*code for stack2*/
void pushs2(void *this1, int x){
	/*Cast the void pointer.*/
	Stack2 *this= (Stack2*)this1;
	int *newArr;
	int i = 0;

	if(this == NULL){
		printf("Could not push element. Stack does not exist: exiting session.");
		exit(0);
	}
	this->entries[this->arrSize] = x;
	/*Change the array size.*/
	this->arrSize = this->arrSize+1;
	/*If array is the same as the length then increase the size of the array*/
	if(this->arrSize == this->length){
		this->length = this->length*2;
		/*Change the size of the entries member*/
		newArr = realloc(this->entries, this->length *sizeof(int));
		if(newArr == NULL){
			free(this->entries);
			printf("Could not allocate space for element\n");
			exit(0);
		}else{
			this->entries = newArr;
		}
	}
	
}

int pops2(void *this1){
	/*Cast the void pointer.*/
	Stack2 *this= (Stack2*)this1;
	int *newArr;
	int i = 0;
	int x;

	/*make sure stack exists and isn't empty*/
	if(this == NULL){
		printf("Could not pop element. Stack does not exist: exiting session.");
		exit(0);
	}
	if (this->arrSize ==0){
		printf("Stack is empty: returning 0.\n");
		return(0);
	}else{
		x = this->entries[this->arrSize-1];
	}

	
	/*Change the array size.*/
	this->arrSize--;
	/*If array is 1/4 of the length then shrink the array*/
	if(this->arrSize == this->length/4){
		this->length = this->length/2;
		/*change the size of the array*/
		newArr = realloc(this->entries, this->length *sizeof(int));
		if(newArr == NULL){
			free(this->entries);
			printf("Could not allocate space for element\n");
			exit(0);
		}else{
			this->entries = newArr;
		}
	}
	/*Return the popped value*/
	return x;
}

/*This function sets the length*/
int lengths2(void *this1){
	Stack2 *this= (Stack2*)this1;
	if(this == NULL){
		printf("Could not get length. Stack does not exist: exiting session.");
		exit(0);
	}
	return this->arrSize;
}

/*Set a new Structure of type Stack2 and set it with default values*/
Stack2* newStack2Make(){
	Stack2 *newStack = malloc(sizeof(Stack2));
	/*Check if allocation failed.*/
	if(newStack == NULL){
			printf("Could not allocate space for Stack\n");
			exit(0);
	}else{
		newStack->length = 5;
		newStack->arrSize = 0;
		newStack->entries = malloc(newStack->length * sizeof(int));
		/*Check if stack2 allocation failed for array.*/
		if(newStack->entries == NULL){
			printf("Could not allocate space for entries\n");
			exit(0);
		}
	}
	
	return newStack;
}


/*Set a new Structure of type Stack and set it with default values*/
/*The Stack member will be set to type Stack2*/
Stack* newStack2(){
	Stack *newStack = malloc(sizeof(Stack));
	/*Check if allocation failed.*/
	if(newStack == NULL){
		printf("Could not allocate space for Stack\n");
		exit(0);
	}else{
		newStack->Stack = newStack2Make();
		newStack->push = &pushs2;
		newStack->pop= &pops2;
		newStack->length= &lengths2;
	}
	
	return newStack;
}
